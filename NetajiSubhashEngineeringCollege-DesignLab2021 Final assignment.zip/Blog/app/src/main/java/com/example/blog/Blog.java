package com.example.blog;

public enum Blog {
}
